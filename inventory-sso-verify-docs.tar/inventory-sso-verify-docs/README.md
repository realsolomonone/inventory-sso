# inventory-sso extras (docs + Python verify)

Two separate folders. Overlay the Python files onto an existing `inventory-sso` checkout. Do not replace the whole repo.

| Folder | Contents |
|--------|----------|
| `docs/` | PowerPoint + AWS architecture diagrams |
| `python-verify/` | Files changed for IAM role verification + HTML report |

See `docs/README.md` and `python-verify/README.md`.
