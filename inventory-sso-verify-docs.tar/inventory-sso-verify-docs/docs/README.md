# Docs

Open the PowerPoint:

`EDL-Resource-Inventory-Terragrunt-Workflow.pptx`

Diagrams (official AWS Architecture Icons). Import `.drawio` in [diagrams.net](https://app.diagrams.net/) or Lucidchart.

| File | Use |
|------|-----|
| `edl-inventory-architecture.drawio` / `.png` | Architecture |
| `edl-inventory-workflow.drawio` / `.png` | Operator workflow |
