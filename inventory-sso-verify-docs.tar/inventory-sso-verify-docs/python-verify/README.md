# Python verification overlay

Copy these files into the **same paths** in `inventory-sso`. Do not copy the whole repo.

```
edl_resource_inventory.py      → inventory-sso/edl_resource_inventory.py
src/html_report.py             → inventory-sso/src/html_report.py
src/models.py                  → inventory-sso/src/models.py
tests/test_html_report.py      → inventory-sso/tests/test_html_report.py
tests/test_verifier.py         → inventory-sso/tests/test_verifier.py
```

From the inventory-sso root:

```bash
source .venv/bin/activate
./scripts/sso-login.sh --all
python edl_resource_inventory.py verify --open
```

Report: `reports/role-verify.html`

Needs the rest of inventory-sso (`src/verifier.py`, AWS SSO, etc.). This folder is only the verify/HTML changes.
