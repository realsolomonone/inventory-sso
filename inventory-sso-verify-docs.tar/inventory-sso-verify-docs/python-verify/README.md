# Python verification overlay

Copy these files into an **existing** `inventory-sso` checkout at the **same paths**. This folder is not a standalone app.

```
edl_resource_inventory.py      → inventory-sso/edl_resource_inventory.py
src/html_report.py             → inventory-sso/src/html_report.py
src/models.py                  → inventory-sso/src/models.py
tests/test_html_report.py      → inventory-sso/tests/test_html_report.py
tests/test_verifier.py         → inventory-sso/tests/test_verifier.py
```

Then follow every step below from the **inventory-sso** directory.

---

## 1. Prerequisites

```bash
python3 --version    # 3.9 or newer
aws --version
ls ~/.aws/config     # SSO profiles present
```

iebcloud if Python is old:

```bash
module avail python
module load python/3.11
python3 --version
```

## 2. Enter the repo and copy overlay files

```bash
cd ~/workspace/inventory-sso
cp /path/to/python-verify/edl_resource_inventory.py ./edl_resource_inventory.py
cp /path/to/python-verify/src/html_report.py ./src/html_report.py
cp /path/to/python-verify/src/models.py ./src/models.py
cp /path/to/python-verify/tests/test_html_report.py ./tests/test_html_report.py
cp /path/to/python-verify/tests/test_verifier.py ./tests/test_verifier.py
```

## 3. Create and activate the virtual environment

```bash
python3 -m venv .venv
source .venv/bin/activate
which python
python --version
```

Windows: `py -3 -m venv .venv` then `.venv\Scripts\activate`

`which python` must be `…/inventory-sso/.venv/bin/python`.

Shortcut instead of steps 3–4:

```bash
python3 edl_resource_inventory.py setup --install
source .venv/bin/activate
```

## 4. Install packages

```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -c "import boto3, yaml, pytest; print('python env ok')"
python edl_resource_inventory.py verify --help
```

## 5. SSO login

```bash
chmod +x scripts/*.sh
./scripts/sso-login.sh --all
./scripts/sso-profiles.sh --check
```

Fix INVALID: `aws sso login --profile PROFILE-NAME`

The IAM role must already exist (Terragrunt apply). Otherwise the report shows **missing**.

## 6. Run verify

```bash
python edl_resource_inventory.py verify --open
```

HTML: `reports/role-verify.html`

If the browser does not open:

```bash
ls -l reports/role-verify.html
open reports/role-verify.html          # macOS
firefox reports/role-verify.html       # Linux
```

## 7. Options

```bash
python edl_resource_inventory.py verify --profiles YOUR_PROFILE --open
python edl_resource_inventory.py verify --no-probe --open
python edl_resource_inventory.py verify --format json
```

Exit: `0` pass, `1` partial, `2` fail.

Needs the rest of inventory-sso (`src/verifier.py`, `src/config_loader.py`, `requirements.txt`, scripts). Overlay only the five files above.
